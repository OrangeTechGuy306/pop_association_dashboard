

export const host = 'http://localhost:5000/auth'
export const fileUrl = 'http://localhost:5000'
//eslint-disable-next-line
export const authID = JSON.parse(localStorage.getItem("apg___") as any) 


export const host = "http://localhost:5000/auth"